### Pages

- Inventory

  - View all wine (id, name, category, price, number in stock, add to cart, actions[for ADMIN only])
  - Filter wine by id, name, category
  - Add wine to cart

- Cart

  - View all items in cart
  - Remove item from cart
  - See total price
  - Generate invoice(send to user email)
  - Mark as sold

- Activity

  - Sales(for USERS)
  - Full Activity (for ADMIN)

- Users (Admin)

  - View all users
  - Delete a user
  - Create new user
