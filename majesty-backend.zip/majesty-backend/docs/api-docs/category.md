base url : /categories

create a new category
    method: POST
    endpoint : /categories/create
    description: creates a new category 



get all categories
    endpoint: /categories/get
    method: GET
